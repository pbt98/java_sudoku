package application;

public class Model {

}
